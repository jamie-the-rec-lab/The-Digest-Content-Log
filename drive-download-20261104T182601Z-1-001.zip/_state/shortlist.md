# Phase 2 shortlist - run 2026-09-02 (edition v2)
# Window 2026-07-08..2026-09-02. All verified in-window and NOT in featured-log.tsv.
# Paths are relative to library/<collection>/transcripts/

## PODCASTS (newest unfeatured in-window per show)
10x Recruiting/2026-07-30-the-recruiting-playbook-behind-cognitions-growth.md
Brainfood/2026-08-19-brainfood-live-on-air-ep398-meet-ema-your-ai-employee-for-hr-it-finan.md
Building the Talent Machine/2026-07-22-episode-041-the-missing-skill-of-recruiting-with-ai-wrebecca-fagan-brandon-jeffs.md
Offer Accepted/2026-08-11-the-north-star-metric-every-hiring-team-needs-with-liz-woodfield-sentilink.md
PromptMates/2026-08-31-claude-greenhouse-mcp-what-can-recruiting-teams-build.md
Recruiting Future/2026-08-21-ep-819-who-gets-the-biggest-job-in-hr.md
Recruiting Roadshow/2026-09-01-information-is-currency-clifton-jadoo-ii-formerly-at-robinhood-the-recruiting-ro.md
The Debrief/2026-08-06-ai-wont-replace-recruiters-but-ai-native-ta-teams-will-replace-yours-the-debrief.md

## NEWSLETTERS
Ashby Community/2026-08-27-your-talent-insights-from-ashby-this-month.md
Full Stack Recruiter/2026-08-27-the-future-of-recruiting-talent-advisor-vs-talent-engineer.md
PromptMates Newsletter/2026-09-01-who-gets-to-win-the-ai-talent-boom.md
RecOps Collective/2026-08-14-week-of-august-10th-2026.md
TA Unboxed/2026-08-28-hiring-is-a-team-sport-your-ats-should-be-too.md

## TECH (subject gate applies: must be about AI, or hiring/talent/teams/people)
AI & I/2026-09-02-how-a-professional-writer-writes-with-ai.md
How I AI/2026-09-02-7-grok-bot-agents-i-use-every-day.md
Lenny's Podcast/2026-08-30-ais-third-era-the-rise-of-persistent-ai-coworkers-tara-seshan-openais-product-le.md

## REPORTS
CIPD/2026-08-16-labour-market-outlook-summer-2026.md   (PARTIAL extraction, key points already in run-report.json)

## EXCLUDED, with reason
REC/2026-07-08-report-on-jobs-july-2026.md      - August edition already featured, never go backwards through a dated series
iCIMS/2026-07-14-workforce-report-july-2026.md  - August edition already featured, same rule
PromptMates/2026-09-03-how-to-partner-with-tech-teams-...md - published 3 Sep, after the run's Wednesday. Eligible next week.
Remade.md - no unfeatured in-window issue, sits out
Recruiting Roadshow _teasers/* - teaser clips, full interviews only

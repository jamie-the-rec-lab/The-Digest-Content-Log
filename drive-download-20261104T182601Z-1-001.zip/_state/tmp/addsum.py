import sys,re
# usage: addsum.py <relpath under library/collection> <collection> <blockfile> <tsvfile>
rel,coll,blk,tsv=sys.argv[1:5]
p=f"library/{coll}/transcripts/{rel}"
s=open(p,encoding='utf-8').read()
if '<!--SUMMARY-->' in s: print('already has summary'); sys.exit()
b=open(blk,encoding='utf-8').read().strip()+"\n"
line=open(tsv,encoding='utf-8').read().strip()
open(p,'w',encoding='utf-8').write(b+s)
t=f"library/{coll}/episode_summaries.tsv"
cur=open(t,encoding='utf-8').read()
if not cur.endswith("\n"): cur+="\n"
if line.split('|||')[0] in cur: print('tsv exists'); sys.exit()
open(t,'w',encoding='utf-8').write(cur+line+"\n")
print('ok',p)

R="&rsquo;"
pod=[
 art("Brainfood","16 Oct 2026","https://www.youtube.com/watch?v=IMYZm_tSsi8","Sourcing, Dead or Alive? Reviewing SOSU 2026",None,[
  f"ServiceNow{R}s sourcers now build talent pools ahead of need and use market data to shape location, pay and profile criteria, says its global head of talent sourcing, Chad Horn.",
  "Sourcing trainer Guillaume says LinkedIn Recruiter shows only 5% of a search with 20K results, so filter based searching misses most of the people it appears to cover.",
  "Panellist Marcel says many teams jump straight to LinkedIn and forget past candidates who already have phone numbers on file, so search your own ATS before searching outside."]),
 art("PromptMates Live","15 Oct 2026","https://www.youtube.com/watch?v=fPLzPKP75ts","Recruiting at Clay: Scaling the Personal Touch","Ryan Ellis · Recruiting Operations Manager @ Clay",[
  "At Clay, submitting a thesis scorecard in Ashby triggers a workflow that posts a Notion briefing to Slack, where a founder approves, denies or discusses with one click instead of joining interviews.",
  "For a high volume support role Clay made the application the assessment: three work simulations graded by AI against a rubric agreed with hiring managers. Candidates can opt out to standard resume review.",
  f"A recruiter pastes a late stage candidate{R}s LinkedIn URL into Slack and gets back current Clay staff who overlapped with them, scored 1 to 10, so a colleague can make contact."]),
 art("Recruiting Future","14 Oct 2026","https://www.youtube.com/watch?v=_9WDe9q8BKM","The Talent Employers Are Throwing Away","JC Townend · President for UK and Ireland @ Adecco Group",[
  f"Townend says about 20% of UK and Ireland redundancies are now attributed to AI, digital or automation and another 20% to a skills mismatch, per her business{R}s own surveys.",
  "She argues skills now change so fast that external hires arrive about 70% to 80% qualified, which shifts the economics towards redeploying existing staff instead of fire and rehire.",
  "Teams know their own skills well but have almost no view across departments, so a finance person is never considered for a marketing role. She suggests mapping transferable skills across the whole company."],last=True),
]
nl=[
 art("Data Driven Recruiter","14 Oct 2026","https://data-driven-recruiter.beehiiv.com/p/issue-82-is-your-candidate-cheating-or-just-good-with-ai","Issue 82 - Is Your Candidate Cheating, Or Just Good With AI??",None,[
  "Luke Eaton draws the line at disclosure: AI use that your rules declare or allow is fluency, hidden use is misuse. He calls it an arbitrary line of his own, and gives ready invite wording.",
  "His AI positive interview tells candidates up front which stages allow AI, keeps one conversation tools closed and one working session AI open, and marks the edit rather than the output.",
  f"92% of employers in the Institute of Student Employers{R} UK survey suspected or caught misconduct, up from 85% last year. Fabric flagged 38.5% of 19,368 AI run interviews but sells detection software."]),
 art("PromptMates Newsletter","13 Oct 2026","https://promptmates.beehiiv.com/p/stop-automating-recruiting-steps-that-shouldn-t-exist","Stop Automating Recruiting Steps That Shouldn&rsquo;t Exist",None,[
  "Before automating a recruiting step, ask what decision it improves and what would happen if you removed it. If nobody can answer clearly, automation may be the wrong next move.",
  f"Luma{R}s Joshua Gill built a one page candidate closing brief from Metaview transcripts and Ashby scorecards, sent as a Slack message when a candidate reaches the final stages, with likely objections and suggested responses.",
  f"Lovable{R}s internal org planning app failed at first because people drifted back to spreadsheets. It stuck once it was connected to HiBob and Ashby data and the data had clear owners."]),
 art("TA Unboxed","9 Oct 2026","https://taunboxed.substack.com/p/how-to-spot-top-talent-in-your-ats","How to spot top talent in your ATS",None,[
  "Darren Bush adds a &ldquo;one to watch&rdquo; field to the recruiter screening form, so a recruiter can record that a candidate stands out while the outcome is still unknown.",
  "Recruiter and hiring manager flag candidates independently, so a TA director reviewing 20 or 50 live roles can see which ones have no candidate anyone believes could do the job.",
  "Timestamp every flag with who set it and the stage, and block backdating, or you measure hindsight rather than talent spotting."]),
 art("RecOps Roundup","8 Oct 2026","https://recops.substack.com/p/week-of-october-5th-2026","Week of October 5th, 2026",None,[
  f"Jeremy Lyons{R}s first tool evaluation question is why the team wants the change, because some changes have no pain point behind them, only a wish to switch to what everyone else uses.",
  "He asks whether there is time to learn the tool, noting onboarding is getting more complicated, and says a high upfront learning cost belongs in the recommendation.",
  f"Lyons{R}s last question is whether to buy or build: if the problem is clearly defined, a simpler fix needing no vendor may exist, provided the time and expertise are there."],last=True),
]
rep=[
 art("Bullhorn &middot; report","13 Oct 2026","https://www.staffingindustry.com/research/research-reports/americas/sia-bullhorn-staffing-indicator-october-13-2026","Staffing Industry Indicator, week ending 3 October 2026",None,[
  "Hours worked by temporary staff at US agencies using Bullhorn were up 11% year on year for the week ending 3 October (index 108), with total, Commercial and Professional hours at year to date highs.",
  "In the US, Industrial hours rose 17% and IT 8% year on year, while Office/Clerical fell 7%. The latest four weeks of readings are preliminary and can be revised."]),
 art("REC &middot; report","10 Oct 2026","https://kpmg.com/uk/en/media/press-releases/2026/10/kpmg-and-rec-uk-report-on-jobs-october-2026.html","UK Report on Jobs, October 2026",None,[
  "UK permanent placements rose for a second month running in September, marginally but at the strongest rate in four years, in the KPMG and REC survey of about 400 recruitment consultancies.",
  "UK permanent candidate supply grew at its weakest rate since September 2023, and permanent salary growth slowed for the first time in four months.",
  "Half of the ten sectors monitored saw higher UK permanent demand, led by IT and Computing and Engineering, while vacancies fell most sharply in Retail and Hotel and Catering."]),
 art("iCIMS &middot; report","8 Oct 2026","https://www.icims.com/company/newsroom/octoberinsights2026/","Workforce Report, October 2026",None,[
  f"In iCIMS{R}s own platform data, US hiring was 7% below the September 2025 baseline while job openings were 3% above it.",
  "US frontline applications were 18% below baseline in September, at 29 applicants per opening, the lowest of the year. Retail time to fill stayed at 37 days.",
  "In the US, 18 to 24 year olds made up 40% of retail applicants in September, up from 37% a year earlier."]),
 art("Workday &middot; launch","13 Oct 2026","https://newsroom.workday.com/2026-10-13-Workday-Launches-Autopilot-Agents-That-Get-Real-Work-Done-Across-HR,-Finance,-and-IT","Autopilot Agents, including a Talent Acquisition Agent",None,[
  "Workday&rsquo;s Talent Acquisition Agent flags open roles at risk of missing their fill date, and once a job is posted it finds qualified candidates and notes their gaps.",
  "When a pipeline is thin it alerts recruiters in tools such as Slack and drafts outreach, but a recruiter must approve before anything is sent.",
  "Only early adopter customers have access now, with general availability planned for early 2027. Descriptions come from Workday, and no customer results have been published."],last=True),
]
tech=[
 art("Lenny&rsquo;s Podcast","11 Oct 2026","https://www.youtube.com/watch?v=3I6QYkccd3o","Why every company now needs to think and operate like a lab team","Josh Woodward · VP of Google Labs @ Google",[
  "Woodward screens hires for unlearning rate, how fast someone can learn a thing and then walk away from it, plus the ability to build and scale trust while working with AI agents.",
  "He keeps a written list of what is &ldquo;almost possible&rdquo; and starts a team when something crosses over. Google Labs&rsquo; list holds 82 predictions, and he expects nine in ten to be wrong.",
  "He says a team usually knows before its leader that an idea is not working, and he publicly thanked a product manager who recommended not launching a Gemini feature after flat early data."]),
 art('AI &amp; I <span class="brand">by Every</span>',"7 Oct 2026","https://www.youtube.com/watch?v=_pcy1_jU27k","OpenAI Dots Took Over Our Company","Willie Williams · Head of Platform @ Every",[
  "Every moved from everyone running a personal agent to one shared company agent, because Williams says non technical staff hit a wall of setup and security and agents decayed when their owners lost interest.",
  "One person&rsquo;s growth agent became the &ldquo;gravitational center&rdquo; as colleagues added to it rather than building their own.",
  "Williams predicts a company agent at work, built up over a year of context, and a personal agent at home. The Every Agent is Every&rsquo;s own product."],last=True),
]
body=sec("Recruiting Podcasts",pod)+sec("Recruiting Newsletters",nl)+sec("Recruiting reports, product updates, and more",rep)+sec("AI &amp; Tech Picks",tech)


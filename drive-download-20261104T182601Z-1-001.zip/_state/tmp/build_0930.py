import re,io
p='digest/builds/2026-09-30.html'
h=open(p,encoding='utf-8').read()
# strip instruction comment
h=re.sub(r'<!--\n  CANONICAL DIGEST TEMPLATE.*?-->\n','',h,count=1,flags=re.S)
h=h.replace('{{DD Mon 2026}}</title>','30 Sep 2026</title>') if False else h.replace('— {{DD Mon 2026}}','— 30 Sep 2026')
h=h.replace('Version {{VERSION}} ({{MONDAY DATE}})','Version 6 (30th September 2026)')

def art(src,date,url,title,pts,guest=None,last=False):
    g='      <div class="guest">%s</div>\n'%guest if guest else ''
    lis=''.join('<li>%s</li>'%x for x in pts)
    return ('    <article class="item%s">\n      <div class="chead"><span class="src">%s</span><span class="cdate">%s</span></div>\n'
            '      <a class="ttl" href="%s" target="_blank" rel="noopener">%s</a>\n%s      <ul class="pts">%s</ul>\n    </article>\n')%(' last' if last else '',src,date,url,title,g,lis)
def sec(label,cnt,items):
    return ('  <section>\n    <details open>\n    <summary class="sec"><span class="lbl">%s</span><span class="cnt">%d</span><span class="chev" aria-hidden="true">›</span></summary>\n    <div class="sbody">\n%s  </div>\n    </details>\n  </section>\n\n')%(label,cnt,items)

G='https://mail.google.com/mail/u/0/#all/'
pod=[
 ('Recruiting Roadshow <span class="brand">by Greenhouse</span>','29 Sep 2026','https://www.youtube.com/watch?v=gosfZkYwZRw','Judgment is the superpower',
  ['Gong shifted about a year ago from inbound applications to sourcing and referrals, because keyword matching and extra recruiter screens still gave no better signal.',
   'Managers at Gong pick a few recorded recruiter calls each week, listen and leave timestamped comments, such as flagging a call that ended without any talk of compensation.',
   'Biggs wants sourcing to start in the ATS, with declined candidates tagged automatically from call transcripts for future roles, and admits &ldquo;we never start there either&rdquo;.'],
  'Kelsey Biggs · VP Global Talent Acquisition @ Gong'),
 ('Recruiting Future','29 Sep 2026','https://www.youtube.com/watch?v=NyFoM2DUvYg','Managing Career Transitions',
  ['Kay describes an executive hired without reference checks because the parties already knew each other, then fired a year later: familiarity is no reason to skip them.',
   'He has not seen AI shorten the time it takes to hire an executive, because the bets are so big, and says AI is used far more for earlier-career hiring.',
   'Kay scores each opportunity on three lenses: quality of the company, quality of the role and quality of the offer, to keep emotion out of the decision.'],
  'Kelly O. Kay · Global Managing Partner, Enterprise Software and AI Practice @ Heidrick &amp; Struggles'),
]
nl=[
 ('Data Driven Recruiter','30 Sep 2026','https://data-driven-recruiter.beehiiv.com/p/ddr80-4-years-of-ai-what-s-actually-changed'.replace('https://data-driven-recruiter.beehiiv.com/p/ddr80-4-years-of-ai-what-s-actually-changed',G+'1a0f2313bd7e32e7'),"DDR80 - 4 Years of AI...What's Actually Changed??",
  ['Ava Labs sources ahead of need: backup pipelines for critical roles, succession gaps, and roles that open when a planned trigger such as a customer milestone is hit.',
   'Ava Labs saves those sourcing sweeps as projects in its ATS, so when a role goes live, recruiters refine what is already there instead of starting from zero.',
   'Buying one AI screening tool and one AI sourcing tool leaves a team&rsquo;s skills, workflows and cost base looking like 2021, the author argues.']),
 ('PromptMates Newsletter','29 Sep 2026',G+'1a0ed43979e2151f','The Scam Email That Fooled a 26-Year Recruiter',
  ['A fake Apple recruiter email passed the LinkedIn check because the recruiter&rsquo;s profile was real; the sender line, Careers HR, and a domain that did not match Apple&rsquo;s gave it away.',
   'Palo Alto&rsquo;s Unit 42 built a passable real-time interview deepfake in about 70 minutes on ordinary consumer hardware, and 18% of recruiters in a 2025 Greenhouse survey said they had already caught applicants using one.',
   'Open the last outreach message you sent a candidate and find one detail they could check independently to prove it came from you. If there is none, that is the work.']),
 ('Full Stack Recruiter','29 Sep 2026',G+'1a0ed5bd42dafe5c','Candidate Quality Complaints Usually Measure the Interviewer',
  ['In one sample of manager performance ratings, the raters&rsquo; own tendencies explained 62% of the variance and actual performance 21% (a 2000 study); the author admits he is stretching it to hiring.',
   'Before sourcing, have the hiring manager rank six anonymised past profiles with one sentence each, then slip two back in among real candidates in week three to see whether their judgement has moved.',
   'A 2022 re-analysis by Paul Sackett and colleagues found structured interviews the strongest predictor of job performance, with a mean validity of .42, ahead of cognitive ability tests at .31.']),
 ('TA Unboxed','25 Sep 2026',G+'1a0d769602fc9277','60 metrics of TA - Part 3 of 3',
  ['Darren Bush classified his 60 TA metrics. 45 (75%) only report something after it happens, and 15 (25%) can work as forward indicators, such as pool burn or recruiter capacity.',
   'He proposes a &ldquo;Hiring ETA&rdquo; for every requisition: a forecast start date and confidence range built from pipeline stage counts, stage-to-hire probabilities, offer acceptance and notice periods.',
   'Hiring Predictability, forecast hires against hires delivered with a target of 85 to 95% accuracy, is how he says TA earns credibility with finance.']), ('Ashby Community','24 Sep 2026',G+'1a0d394ac99d778d','Your Talent Insights from Ashby This Month',
  ['Ashby now supports two-way WhatsApp texting with candidates on all plans, with automated interview reminders, aimed at markets like Brazil, the Middle East and much of APAC where SMS is not how candidates talk.',
   'A 70,000 applicant study summarised by Jonathan Duarte found AI-interviewed candidates got 12% more offers and finished interviews 4x faster. 78% chose AI when given the choice, and humans still made every decision.',
   'Paul Lee of InnoCaption found about 1,500 characters of white-on-white text in a resume, telling AI systems to ignore prior commands and rate the candidate as highly qualified.']),
]
rep=[
 ('Bullhorn &middot; report','29 Sep 2026','https://www.bullhorn.com/insights/staffing-industry-indicator/','Staffing Industry Indicator, week ending 19 September 2026',
  ['US staffing hours were up 10% year over year and 7.2% week over week, in Bullhorn&rsquo;s indicator of hours worked by temporary workers across its US staffing customers.',
   'US industrial staffing hours rose 15% year over year, which the report attributes to manufacturing, logistics and data centre demand.',
   'Not every US segment rose: office and clerical staffing hours fell 8% year over year, while commercial rose 11%, professional 8% and IT 6%.']),
]
tech=[
 ("Lenny's Podcast",'27 Sep 2026','https://www.youtube.com/watch?v=5-96FyJFiCA','Molly Graham: the grief, burnout, and opportunity hiding inside the AI transition',
  ['Burnout among tech workers in Lenny&rsquo;s survey rose from 44% in 2025 to 55% this year.',
   'Graham says to treat AI like a lazy intern: edit its output before it goes to anyone else, because pasting and sending it passes the clean-up to colleagues.',
   'She says many layoffs blamed on AI are really poorly managed companies using AI as the label.'],
  'Molly Graham · Founder @ Glue Club'),
]
def render(items,label):
    out=''
    for i,it in enumerate(items):
        if len(it)==6: s,d,u,t,pts,g=it
        else: s,d,u,t,pts=it; g=None
        out+=art(s,d,u,t,pts,g,last=(i==len(items)-1))
    return out
body=''
body+=sec('Recruiting Podcasts',len(pod),render(pod,''))
body+=sec('Recruiting Newsletters',len(nl),render(nl,''))
body+=sec('Recruiting reports, product updates, and more',len(rep),render(rep,''))
body+=sec('AI &amp; Tech Picks',len(tech),render(tech,''))

brief=("Two newsletters question how hiring is measured: how much a &ldquo;poor candidate&rdquo; verdict reflects the person judging, and why 75% of one author&rsquo;s 60 TA metrics only look back. "
 "Ava Labs sources ahead of demand, Gong moved from inbound applications to sourcing and referrals, and a convincing fake Apple recruiter email shows how hard outreach scams are to spot. "
 "Ashby&rsquo;s newsletter relays a 70,000 applicant study where AI interviews produced 12% more offers, and US staffing hours rose 10% year over year. "
 "And in the world of AI, Molly Graham says burnout among tech workers in Lenny&rsquo;s survey rose to 55%.")
def pick(lbl,url,name,why):
    return '      <li><span class="pick">%s</span><span class="body"><a href="%s" target="_blank" rel="noopener">%s</a><span class="why">%s</span></span></li>\n'%(lbl,url,name,why)
stand=''.join([
 pick('Podcast','https://www.youtube.com/watch?v=gosfZkYwZRw','Recruiting Roadshow, Judgment is the superpower (Kelsey Biggs)','Gong&rsquo;s head of global talent acquisition says inbound applications stopped giving signal, so her team moved to sourcing and referrals, and managers coach recruiters through timestamped comments on recorded calls.'),
 pick('Newsletter',G+'1a0ed5bd42dafe5c','Full Stack Recruiter, Candidate Quality Complaints Usually Measure the Interviewer','One study put 62% of the variance in manager ratings down to the rater. The author stretches it to hiring, then offers a six-profile blind packet you can have the hiring manager rank in week one and re-test in week three.'),
 pick('Report','https://www.bullhorn.com/insights/staffing-industry-indicator/','Bullhorn Staffing Industry Indicator, week ending 19 September 2026','US staffing hours were up 10% year over year, with industrial up 15% and office and clerical down 8%, a current US figure to quote on temporary labour demand.'),
 pick('AI pick','https://www.youtube.com/watch?v=5-96FyJFiCA',"Lenny's Podcast, Molly Graham: the grief, burnout, and opportunity hiding inside the AI transition",'Burnout among tech workers in Lenny&rsquo;s survey rose from 44% to 55%, and her advice is to treat AI like a lazy intern and edit its output before it goes to anyone else.'),
])
start=h.index('  <div class="summary">')
end=h.index('  <p class="foot">')
new=('  <div class="summary">\n    <p class="brief-label">This week in the world of recruiting</p>\n    <p class="brief-text">%s</p>\n    <h2 class="sh">Standout content from this week</h2>\n    <ul>\n%s    </ul>\n  </div>\n\n')%(brief,stand)+body
h=h[:start]+new+h[end:]
open(p,'w',encoding='utf-8').write(h)
print('ok')

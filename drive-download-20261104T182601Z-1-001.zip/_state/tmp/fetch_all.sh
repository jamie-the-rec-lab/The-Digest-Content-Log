export PATH="$HOME/.local/bin:$PATH"
cd "$HOME/mnt/Podcast Project"
f(){ python3 scripts/fetch_transcripts.py "$@"; sleep 5; }
f 'https://www.youtube.com/@10x_Recruiting_pod/videos' '10x Recruiting' podcasts/transcripts
f 'https://www.youtube.com/channel/UCNJ1ECjprHORfyAbE5qyqcg/videos' 'Brainfood' podcasts/transcripts 20240101
f 'https://www.youtube.com/@buildingthetalentmachine/videos' 'Building the Talent Machine' podcasts/transcripts 20240101
f 'https://www.youtube.com/playlist?list=PLrd3ZPgPqLzmHvhgRKY0IH_5-1TuiDLDM' 'Offer Accepted' podcasts/transcripts
f 'https://www.youtube.com/channel/UCBK-L-lWoLkSZw93S3f5VhQ/videos' 'PromptMates' podcasts/transcripts
f 'https://www.youtube.com/channel/UCBK-L-lWoLkSZw93S3f5VhQ/streams' 'PromptMates' podcasts/transcripts
f 'https://www.youtube.com/user/mattalder1/videos' 'Recruiting Future' podcasts/transcripts 20240101
f 'https://www.youtube.com/playlist?list=PLGaFEEU4PKYwIQnkoGFLf3goOyeSudypy' 'Recruiting Roadshow' podcasts/transcripts
f 'https://www.youtube.com/@thedebriefTApodcast/videos' 'The Debrief' podcasts/transcripts
f 'https://www.youtube.com/playlist?list=PLuMcoKK9mKgHtW_o9h5sGO2vXrffKHwJL' 'AI & I' tech/transcripts 20260101
f 'https://www.youtube.com/@howiaipodcast/videos' 'How I AI' tech/transcripts 20260101
f "https://www.youtube.com/@LennysPodcast/videos" "Lenny's Podcast" tech/transcripts 20260101
f 'https://www.youtube.com/@AIForHumansShow/videos' 'AI For Humans' tech/transcripts 20260101
echo ALLDONE

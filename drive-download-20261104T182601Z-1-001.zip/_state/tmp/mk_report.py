import json
def kp(point,quote): return {"point":point,"quote":quote}
R={}
R["date"]="2026-10-07"; R["run_date"]="2026-10-07"; R["phase"]="1 refresh"
R["status"]="complete with gaps: library refreshed and verified; some YouTube episodes had no captions, Indeed report unreachable, several vendor pages unreadable (see failed_sources and launch_sweep)"
R["report_completeness"]="partial"
R["report_completeness_note"]="Library items are complete. Reports collection: 1 ingested (Criteria, partial extraction); Bullhorn SIA had no new edition; Indeed Hiring Lab UK Sept snapshot could not be fetched (second week). Launch sweep ran but 5 vendor pages were unreadable or undated, so those vendors are unconfirmed rather than confirmed empty."
R["collections"]={
 "podcasts":{"10x Recruiting":0,"Brainfood":0,"Building the Talent Machine":0,"Offer Accepted":0,"PromptMates":2,"Recruiting Future":0,"Recruiting Roadshow":0,"The Debrief":0},
 "tech":{"AI & I":0,"How I AI":0,"Lenny's Podcast":2,"AI For Humans":0},
 "newsletters":{"Ashby Community":0,"Data Driven Recruiter":0,"Full Stack Recruiter":0,"PromptMates Newsletter":1,"RecOps Collective":1,"Remade.md":0,"TA Unboxed":1},
 "adhoc":{},
 "reports":{"Criteria":1,"Bullhorn":0},
 "news":{"OpenAI":1}}
R["collection_notes"]={
 "How I AI":"fetch_transcripts reported 1 'saved' (OpenAI DevDay 2026, 30 Sep) but that episode was already in the library and summarised last week, so it is counted as 0 new.",
 "Recruiting Roadshow":"1 episode routed to _teasers (Respect in the hiring process, S2 Ep 10 teaser), not indexed.",
 "PromptMates":"2 new items: the 30 Sep live show 'ChatGPT for Recruiters' (undated by the script, date 2026-09-30 recovered from yt-dlp metadata) and a 4 Oct clip of the same session."}
R["reports"]=[{"name":"Criteria Corp Hiring Benchmark Report 2026-2027 (ninth annual)","extraction":"partial","url":"https://www.criteriacorp.com/research/2026-2027-hiring-benchmark-report","path":"reports/transcripts/Criteria/2026-10-06-hiring-benchmark-report-2026-2027.md","reason":"press release (PR Newswire, 2026-10-06) plus landing-page preview; full report behind a download form. Added to _TO_GRAB.md."},
 {"name":"Bullhorn Staffing Industry Indicator","extraction":"none new","reason":"page still shows week ending 19 September 2026 (page modified 29 September), already held. Returned nothing new, not a failure."}]
R["to_grab"]=[
 {"name":"Criteria Corp Hiring Benchmark Report 2026-2027","reason":"partial held; full PDF behind a form"},
 {"name":"Indeed Hiring Lab UK Labour Market Snapshot September 2026","reason":"published 2026-09-28; 'Too many redirects' again on 2026-10-07; needs a human drop into _inbox/"},
 {"name":"Draup Macro Labor Market Trends 2026","reason":"carried from 2026-09-30: borderline vendor press release, full report gated; not ingested"},
 {"name":"KPMG/REC UK Report on Jobs September 2026","reason":"carried over: permanent subscription gate, partial held; the October edition was not yet published when searched on 2026-10-07"}]
R["index"]={
 "podcasts":{"items":725,"missing":0,"blocks":"137/725","warnings":[]},
 "tech":{"items":206,"missing":0,"blocks":"46/206","warnings":[]},
 "newsletters":{"items":58,"missing":0,"blocks":"n/a","warnings":[]},
 "reports":{"items":76,"missing":0,"blocks":"n/a","warnings":["Index reports 76 items after adding 1 (last week's report said 74), so the earlier count was one low; not investigated."]},
 "news":{"items":7,"missing":0,"blocks":"n/a","warnings":[]},
 "adhoc":{"items":2,"missing":0,"blocks":"n/a","warnings":["2 June-dated items predate this run and carry no summary block; not new, untouched"]}}
R["verification"]={"build_index":"all six collections rebuilt, 0 missing index lines, CHECK clean on each","check_summaries":"exit 1 with 25 problem blocks, all older than this run (same count as last week). The 4 blocks written this run (PromptMates x2, Lenny's x2) were checked individually and have no problems."}
R["zero_returns"]=[]
R["zero_return_note"]="No source reported 'found 0 videos' or an empty listing. Sources with nothing new this week (a genuine quiet week, not a fetch failure): 10x Recruiting, Brainfood (captioned episodes), Building the Talent Machine, Offer Accepted (captioned), Recruiting Future, Recruiting Roadshow, The Debrief, AI & I, AI For Humans, How I AI, Ashby Community, Data Driven Recruiter, Full Stack Recruiter, Remade.md, Bullhorn SIA."
R["failed_sources"]=[
 {"source":"YouTube captions: Brainfood Ep411 (2026-10-02), Ep409 (2026-09-18), Ep408 (2026-09-17)","error":"nosubs (no captions available) on two attempts","status":"left for next week"},
 {"source":"YouTube captions: Offer Accepted 'Cutting a 5-Round Sales Interview Process Down to 3' (2026-10-06) and one untitled video","error":"nosubs on two attempts","status":"left for next week"},
 {"source":"YouTube captions: PromptMates streams 'Talent Engineering (Live Demos)' and 'Talent Engineering at Clay'","error":"nosubs on two attempts","status":"left for next week"},
 {"source":"YouTube captions: tech, AI & I (Sam Altman Dots), How I AI (5 episodes), Lenny's (6 episodes), AI For Humans (4 episodes)","error":"nosubs; on the end-of-phase sweep one Lenny's episode (Anthropic CPO panel) did save, the rest still had none. Three attempts total, stopped.","status":"left for next week; may be fresh uploads whose captions are not generated yet"},
 {"source":"Indeed Hiring Lab UK snapshot (hiringlab.indeed.com)","error":"Too many redirects (second consecutive week)","status":"left for next week, in _TO_GRAB.md"},
 {"source":"Vendor pages Workable, Lever, SmartRecruiters, First.cx substack","error":"pages returned no usable dated entries (help index, stale 2016 content, JS shell)","status":"swept via search, nothing dated found; unconfirmed"},
 {"source":"Morningstar copy of Juicebox/Fetcher Business Wire release","error":"403","status":"read the Juicebox post and a Yahoo Finance copy instead"}]
R["launches_swept"]=True
R["launch_sweep"]={"ran":True,"tool":"WebFetch on vendor feeds and pages, WebSearch for search-type vendors and for pages that came back empty",
 "read":["Ashby (latest dated update 2026-05-07)","Gem blog (no dates on listing)","Greenhouse (latest Release Notes July 2026 listed)","Jack & Jill (latest post 2026-09-15, already featured)","Juicebox","Metaview (RSS via content.metaview.ai, latest 2026-10-05, content marketing only)","Pinpoint (latest 2026-08-04)","Teamtailor (latest 2026-09-10)","Pin (latest 2026-09-28, review articles only)","Eightfold (listing undated; Candidate Agent dated 2026-07-16 via IT Brief)","iCIMS (Summer 2026 release, page modified 2026-07-08; iCIMS NEXT event on 2026-10-08)"],
 "searched_only":["hackajob/Archer","Nova","Screenloop","Workday"],
 "could_not_read":["Workable (help page, no entries)","Lever (index page only)","SmartRecruiters (returned a 2016 page)","First.cx (JS shell)"],
 "result":"One qualifying item: Juicebox agreement to acquire Fetcher's assets (2026-10-06). Everything else dated in the window was marketing content or already featured. Archer free tier (announced on PromptMates Live 2026-09-30) has no fetchable official page or date, so it is a gap, not a candidate. Not saved to library/news, per REFRESH (saved only if featured)."}
R["launch_candidates"]=[{"vendor":"Juicebox","release":"Agreement to acquire Fetcher's assets","type":"acquisition","date":"2026-10-06","url":"https://juicebox.ai/blog/juicebox-acquires-fetcher-assets",
 "second_source":"Business Wire release via Yahoo Finance: https://finance.yahoo.com/technology/ai/articles/juicebox-announces-agreement-acquire-fetcher-220000787.html",
 "line":"Juicebox has agreed to acquire the assets of recruiting sourcing platform Fetcher as Fetcher retires, offering Fetcher customers a transition.",
 "quote":"Juicebox has reached an agreement to acquire Fetcher's assets as the platform retires.",
 "further_quotes":["Fetcher pioneered human-in-the-loop recruiting software in 2016, raised over $30 million, served 1,500+ companies, and empowered 5,000+ recruiters.","Fetcher customers will have the option to transition to Juicebox as Fetcher winds down its existing product and operations."],
 "gaps":"No financial terms were disclosed in the Yahoo copy of the release. A third-party site (beri.net) claims Fetcher shuts down 16 October; not fetched and not confirmed by either primary source. Juicebox's own post mentions an exclusive offer through 19 November. Press says Juicebox has raised $116M to date (Yahoo copy of the release).",
 "note":"Not yet saved to library/news. If featured, Phase 2 must save the Juicebox post into library/news/transcripts/Juicebox/."}]
R["ai_news"]={"title":"OpenAI unveils Dots, always-on agents, at DevDay","date":"2026-09-29","path":"news/transcripts/OpenAI/2026-09-29-dots-always-on-agents-devday.md",
 "sources":["https://letsdatascience.com/news/openai-introduces-dots-always-on-ai-agents-at-devday-2026-2ced4872","https://www.businesstoday.in/technology/artificial-intelligence/story/openai-introduces-dots-always-on-ai-agents-that-work-247-and-act-on-your-behalf-558688-2026-09-30"],
 "extraction":"full text of two independent outlets; OpenAI's own announcement page was not fetched",
 "key_points":[kp("Dots are always-on agents that keep working toward a goal inside limits the user sets","Users give a Dot a goal and set boundaries for what it may do on its own; the agent can keep work moving in the background and contact the user when it needs attention or more detail."),
  kp("Launch availability is narrow: Pro and Business Premium in eligible markets, enterprise beta off by default, one Dot per user","Dots are available to Pro and Business Premium users in eligible markets."),
  kp("Business Today says each Dot has its own browser and over 4,000 app plugins and integrates with ChatGPT, Slack and Microsoft Teams (single source for this detail; Let's Data Science does not give it)","describing them as \"remarkably capable, always-on agents built to handle everything.\"")],
 "recruiter_angle":"Practitioner commentary only (PromptMates Live 30 Sep 2026): a recruiter could delegate chasing hiring managers and intake preparation. Neither article mentions recruiting. Weaker pick if Phase 2 wants a recruiting-specific story; no better candidate was found in the scan. Also seen in the scan: Claude Opus 5.5 (PromptMates newsletter says 40% cheaper than Opus 5, not verified at source) and Tavus Griffin (48% of participants in one-minute calls thought it was a real person, newsletter claim, not verified at source)."}
R["problems"]=[
 {"phase":1,"source":"process","what":"No sub-helper (Agent) tool was available, so transcripts and email bodies were read in the main thread, against TOKEN_RULES 1. Summaries were written quote-first per SUMMARY_SPEC and verified with check_summaries.py and build_index.py.","severity":"degraded","resolved":"no"},
 {"phase":1,"source":"YouTube captions","what":"Many recent episodes returned nosubs (see failed_sources). Several are 2-3 weeks old (Brainfood Ep408/409), so the cause may be permanent absence of auto captions, not delay.","severity":"degraded","resolved":"no"},
 {"phase":1,"source":"Indeed Hiring Lab UK","what":"Too many redirects, second week running.","severity":"degraded","resolved":"no"},
 {"phase":1,"source":"fetch_transcripts","what":"Re-saved an already held How I AI episode as 'saved'; summary block intact, index clean.","severity":"noted","resolved":"yes"},
 {"phase":1,"source":"summary attribution","what":"Two Lenny's Summit panel transcripts have unlabelled speakers and one is garbled by machine translation; the summary blocks say attributions are inferred. Phase 2 should quote them cautiously.","severity":"noted","resolved":"no"},
 {"phase":1,"source":"check_summaries","what":"25 older blocks with unverifiable figures remain; none from this run.","severity":"noted","resolved":"no"}]

def pod(show,title,date,guest,path,kps):
    return {"show":show,"title":title,"date":date,"guest":guest,"path":path,"key_points":kps,"key_points_source":"transcript body (read in full), not the episode description","summary_block":True}
NI={}
NI["podcasts"]=[
 pod("PromptMates","ChatGPT for Recruiters (PromptMates Live)","2026-09-30","Leandro Gomez Silva, founder of Remade.md and head of AI operations at Noble Recruitment; sponsor segment with Mark, CEO of Archer (formerly hackajob), a vendor","podcasts/transcripts/PromptMates/2026-09-30-chatgpt-for-recruiters.md",[
  kp("Archer (sponsor, vendor claim, unverified): daily scale of its autonomous introductions","Archer is working across 15,000 jobs, is qualifying 450,000 candidates, making 2,000 intros fully autonomously."),
  kp("Gomez Silva: the recruiter's role shifts from order taker to adviser who arrives prepared","not be order takers. We need to be advisers"),
  kp("Autonomy rule relayed from a Cursor executive: do not delegate irreversible actions","I would never push anything to an agent that is irrevocable"),
  kp("Gomez Silva's operating rule: agents identify themselves and never impersonate the recruiter","it always identifies as an agent and it never pretends to be me"),
  kp("Scheduling can be agent-run for most roles, but busy roles still need a human coordinator","for 70% of the roles that most of us are working on, it can probably do the job"),
  kp("Dots (OpenAI) connects to over 4,000 apps, per Gomez Silva (early access only)","it's an agent that works on its own in the cloud and is connected to over 4,000 apps")]),
 pod("PromptMates","If I Were Recruiting Today, I'd Use ChatGPT Like This (clip of the 30 Sep live show)","2026-10-04","Leandro Gomez Silva, head of AI operations at Noble (hypothetical hire at Buffer)","podcasts/transcripts/PromptMates/2026-10-04-if-i-were-recruiting-today-id-use-chatgpt-like-this.md",[
  kp("Gomez Silva does not use AI stack ranking yet because of the EU AI Act; a human reviews the shortlist","I don't do stack ranking yet"),
  kp("At Noble, one in two agent-presented profiles goes through to outreach","we have one out of every two presented profiles are being put through to the next round, which is the outreach route"),
  kp("Agent decisions stay suggestions with evidence; the recruiter decides","it never rejects or accepts someone. It gives me suggestions, but I'm the one making the decision."),
  kp("Source from your own ATS before external outreach","I'm a big fan of sourcing in your own ATS first."),
  kp("The agent can surface intake discrepancies, e.g. staff title versus senior budget, to turn into pre-read questions","the rule says staff but the budget sits on a senior salary")])]
NI["tech"]=[
 pod("Lenny's Podcast","Stop planning for 2027: how OpenAI builds product 90 days at a time","2026-09-29","Tara Seshan and Nan Yu, product leaders at OpenAI, interviewed by Claire Vo (speaker attributions inferred, turns unlabelled)","tech/transcripts/Lenny's Podcast/2026-09-29-stop-planning-for-2027-how-openai-builds-product-90-days-at-a-time-tara-sesha-an.md",[
  kp("Plan only two to three months ahead","the ideal is two to three months"),
  kp("Ship features that aim where models will be in two to three months","aiming for 2 to 3 months of like where the models will be"),
  kp("Last-mile failure is worse than a non-starter, hence computer use as fallback","99% there and then it just barfs"),
  kp("Managing many agents mirrors managing many reports","40 agents is quite a lot, right?")]),
 pod("Lenny's Podcast","Why Claude can't be your PM (yet) | Anthropic CPO Panel","2026-09-29","Ami Vora and Mike Krieger, product leaders at Anthropic, interviewed by Dan Shipper (speaker attributions inferred; transcript machine-garbled in places)","tech/transcripts/Lenny's Podcast/2026-09-29-why-claude-cant-be-your-pm-yet-anthropic-cpo-panel.md",[
  kp("Technology change cadence has shortened to about every 2 months","technology used to change every 10 or 5 years, and now it seems like it changes every 2 months"),
  kp("A human organiser was still needed on an AI-assisted project","we really need a PM on this project"),
  kp("Instagram lesson: main feed dominated usage, so say no to extra tabs","The main feed was about 80% usage, right?"),
  kp("Prefer overlapping experiments over one over-constrained product","I would rather have five products that overlap and work differently than one that is too limited")])]
NI["newsletters"]=[
 {"name":"TA Unboxed","title":"A better way to measure candidate quality","date":"2026-10-02","path":"newsletters/transcripts/TA Unboxed/2026-10-02-a-better-way-to-measure-candidate-quality.md","public":"https://taunboxed.substack.com/p/a-better-way-to-measure-candidate","key_points":[
  kp("Darren Bush proposes a 1 to 5 confidence score per candidate at every stage gate, scored independently by recruiter and hiring manager, locked once the next stage begins","every candidate gets a confidence score — 1 to 5 — at every stage gate they pass through"),
  kp("Example funnel snapshot used to show the funnel hides quality","28 people at application, scored nowhere"),
  kp("An early high score outranks a late low score","A 4-rated candidate at the screening stage is more valuable than a 2-rated candidate at the final interview."),
  kp("Sponsor note: the issue is sponsored by Metaview (fillmore agent waitlist)","A quick word from this edition's sponsor, Metaview")]},
 {"name":"PromptMates Newsletter","title":"Two Recruiters Let AI Into Their Hiring Data","date":"2026-10-06","path":"newsletters/transcripts/PromptMates Newsletter/2026-10-06-two-recruiters-let-ai-into-their-hiring-data.md","public":"https://promptmates.beehiiv.com/p/two-recruiters-let-ai-into-their-hiring-data","key_points":[
  kp("Linktree's Nathalie Grandy found a comp-band gap via MCP-connected data","70% of product marketing candidates were negotiating 15% above the company's official comp bands"),
  kp("Remote's Clara Vallejo lifted interview-to-offer after connecting Sigma and BrightHire data","pull interview-to-offer up to roughly 18% within six weeks"),
  kp("iCIMS survey of 1,000 US adults on AI training (reported secondhand)","An ICIMS survey of 1,000 U.S. adults found 14% of job seekers would take lower pay for a job that offers AI training, and 42% say AI training makes an employer more attractive."),
  kp("Claude Opus 5.5 cost claim (newsletter's wording, not verified at source)","costing 40% less to run than Opus 5"),
  kp("Tavus Griffin demo claim (newsletter's wording, not verified at source)","48% of participants believed they were talking to a real person")]},
 {"name":"RecOps Collective","title":"Week of September 28th, 2026","date":"2026-10-02","path":"newsletters/transcripts/RecOps Collective/2026-10-02-week-of-september-28th-2026.md","public":"https://recops.substack.com/p/week-of-september-28th-2026","key_points":[
  kp("Jeremy Lyons, quoting Luke Eaton's DDR80: buying AI point tools is not an AI-enabled team","If your team's AI strategy is an AI screening tool plus an AI sourcing tool then all you have done is buy two SaaS products."),
  kp("Vendor roundup lists Metaview's $60m raise (already covered last week)","Announcement: Raised $60m"),
  kp("Upcoming event: Greenhouse webinar on its Ezra AI Labs acquisition, week of 19 October","Build, Buy, or Partner: What Greenhouse’s Acquisition of Ezra AI Labs Tells Us About Where Talent Technology Is Heading")]}]
NI["reports"]=[{"name":"Criteria Corp Hiring Benchmark Report 2026-2027","date":"2026-10-06","path":"reports/transcripts/Criteria/2026-10-06-hiring-benchmark-report-2026-2027.md","extraction":"partial","key_points":[
  kp("Sample: 1,027 US hiring professionals, largest to date; vendor-run survey","The 2026 report compiles responses from 1,027 U.S-based hiring professionals, the largest sample to date"),
  kp("Hiring difficulty","More than half (52%) of hiring professionals say hiring is harder in 2026"),
  kp("AI and entry-level hiring; Gen Z readiness","More than one-third (37%) of hiring professionals say AI may be reducing the need to hire entry-level workers, while just 16% believe Gen Z is well-prepared for the workplace."),
  kp("AI optimism versus job-loss belief","71% are optimistic about AI in hiring, but 53% also believe AI will eliminate more jobs than it creates")]}]
NI["ai_news"]=R["ai_news"]
R["new_items"]=NI
json.dump(R,open('_state/run-report.json','w'),indent=1,ensure_ascii=False)
print(R["date"],R["run_date"])

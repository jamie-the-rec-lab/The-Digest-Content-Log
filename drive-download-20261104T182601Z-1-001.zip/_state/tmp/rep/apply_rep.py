import json,os
root=os.path.expanduser("~/mnt/Podcast Project/library")
d=os.path.dirname(os.path.abspath(__file__))
for e in json.load(open(os.path.join(d,"rep_manifest.json"))):
    p=os.path.join(root,e["coll"],"transcripts",e["rel"]); os.makedirs(os.path.dirname(p),exist_ok=True)
    if os.path.exists(p): print("exists",e["rel"]); continue
    open(p,"w",encoding="utf-8").write(open(os.path.join(d,e["src"]),encoding="utf-8").read())
    tsv=os.path.join(root,e["coll"],"episode_summaries.tsv"); cur=open(tsv,encoding="utf-8").read()
    if e["rel"]+"|||" not in cur:
        if not cur.endswith("\n"): cur+="\n"
        open(tsv,"w",encoding="utf-8").write(cur+f"{e['rel']}|||{e['summary']}|||{e['company']}|||{e['tags']}\n")
    print("ok",e["rel"])

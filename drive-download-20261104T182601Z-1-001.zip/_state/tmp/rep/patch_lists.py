import os
root=os.path.expanduser("~/mnt/Podcast Project/library/reports")
w=os.path.join(root,"WATCHLIST.md"); t=open(w,encoding="utf-8").read()
old="| 2026-09 (week ending 12 Sep) |"
if old in t:
    t=t.replace(old,"| 2026-09 (week ending 19 Sep) |"); open(w,"w",encoding="utf-8").write(t); print("watchlist updated")
else: print("watchlist pattern not found")
g=os.path.join(root,"_TO_GRAB.md"); s=open(g,encoding="utf-8").read()
add="""
## Flagged 2026-09-30 (not ingested)

- Draup, "Macro Labor Market Trends 2026: A Draup Perspective" (press release dated 2026-09-30 on PR Newswire: prnewswire.com/news-releases/draup-report-finds-ai-builder-roles-now-claim-27-of-tech-demand-as-companies-rethink-hiring-302893864.html). Vendor report on its own dataset ("more than one billion tracked profiles and job descriptions", cohort data corroborated against the Stanford Digital Economy Lab). Full report is behind a form on the Draup site. Borderline under the reputability bar (vendor press release, methodology only described in one line), so flagged for a human look rather than ingested. Headline figures in the release: AI Builder roles at 27% of technology demand; internships and contract roles 27% of early-career hiring, up from 13% in 2020.
- Indeed Hiring Lab UK, "UK Labour Market Snapshot, September 2026" (published 2026-09-28, hiringlab.indeed.com/uk/blog/2026/09/28/uk-labour-market-snapshot-september-2026/). Watchlist item, new edition in window. The fetch returned "Too many redirects" on every attempt, so it is not captured. If it still fails next week, drop the PDF or text into _inbox/.
"""
if "Flagged 2026-09-30" not in s:
    open(g,"a",encoding="utf-8").write(add); print("to_grab appended")

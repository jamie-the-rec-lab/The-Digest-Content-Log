import os
root=os.path.expanduser("~/mnt/Podcast Project/_state")
d=os.path.dirname(os.path.abspath(__file__))
rows=open(os.path.join(d,"runlog_rows.tsv"),encoding="utf-8").read()
p=os.path.join(root,"RUN_LOG.tsv")
cur=open(p,encoding="utf-8").read()
with open(p,"a",encoding="utf-8") as f:
    if not cur.endswith("\n"): f.write("\n")
    f.write(rows)
print("appended")

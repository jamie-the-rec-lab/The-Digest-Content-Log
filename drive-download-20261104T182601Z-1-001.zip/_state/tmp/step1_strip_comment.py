import re
path = "digest/builds/2026-09-23.html"
s = open(path, encoding="utf-8").read()
s2 = re.sub(r"<!--\n  CANONICAL DIGEST TEMPLATE.*?-->\n", "", s, flags=re.S)
assert s2 != s, "comment not stripped"
open(path, "w", encoding="utf-8").write(s2)
print("stripped, new length", len(s2))

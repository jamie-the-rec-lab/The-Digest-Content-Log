path = "digest/builds/2026-09-23.html"
s = open(path, encoding="utf-8").read()

s = s.replace(
    "<title>TheRecLab Weekly Digest — {{DD Mon 2026}}</title>",
    "<title>TheRecLab Weekly Digest — 23 Sep 2026</title>"
)
s = s.replace(
    '<div class="date">Version {{VERSION}} ({{MONDAY DATE}})</div>',
    '<div class="date">Version 5 (23rd September 2026)</div>'
)
open(path, "w", encoding="utf-8").write(s)
print("done")

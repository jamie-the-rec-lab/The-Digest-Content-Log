# -*- coding: utf-8 -*-
path = "digest/builds/2026-09-23.html"
s = open(path, encoding="utf-8").read()

old = '''    <p class="brief-text">{{ 2-3 cohesive, engaging sentences previewing the TOPICS covered this week, so a reader knows what to expect; grounded in the items actually featured, no invented specifics. If the week is too thin for a real preview, DELETE BOTH this brief-text line AND the brief-label line above it. }}</p>
    <h2 class="sh">Standout content from this week</h2>
    <ul>
      <li><span class="pick">Podcast</span><span class="body"><a href="{{url of the podcast item}}" target="_blank" rel="noopener">{{recruiting show, episode title (guest)}}</a><span class="why">{{the why, 25-50 words for the whole standout}}</span></span></li>
      <li><span class="pick">Newsletter</span><span class="body"><a href="{{url of the newsletter item, per the NEWSLETTER LINK RULE: gmail permalink in the LOCAL copy, public archive URL in the PUBLIC copy}}" target="_blank" rel="noopener">{{newsletter, issue}}</a><span class="why">{{the why}}</span></span></li>
      <li><span class="pick">Report</span><span class="body"><a href="{{url of the report item}}" target="_blank" rel="noopener">{{report name}}</a><span class="why">{{the why; DELETE this whole li if no genuine report this week}}</span></span></li>
      <li><span class="pick">Launch</span><span class="body"><a href="{{url of the launch item}}" target="_blank" rel="noopener">{{launch name}}</a><span class="why">{{the why; DELETE this whole li if no genuine launch this week}}</span></span></li>
      <li><span class="pick">AI news</span><span class="body"><a href="{{url of the AI news item}}" target="_blank" rel="noopener">{{the one AI development on a recruiter's radar}}</a><span class="why">{{the why; if the AI news item has NO link, drop the <a> and keep just the title text in the body span; DELETE this whole li if nothing clears the bar}}</span></span></li>
    </ul>'''

brief = ("Candidate fraud gets two accounts this week: Proof's Lauren Furey points to organised "
"programmes out of North Korea, while practitioner Adrian Russo puts the motive on stealing IP "
"and names China too. Both want the fix owned above a single tool purchase, by IT, security and "
"an executive sponsor. Plaid runs recruiting support like a helpdesk while Jake Lamb has built 20 "
"Claude skills across his own hiring funnel, and US staffing hours ran 11% above last year per "
"Bullhorn. Pin and Workable both shipped new AI features, and Colorado and Connecticut have "
"enacted notify-and-explain rules for automated hiring tools.")

new = f'''    <p class="brief-text">{brief}</p>
    <h2 class="sh">Standout content from this week</h2>
    <ul>
      <li><span class="pick">Podcast</span><span class="body"><a href="https://www.youtube.com/watch?v=OA-PLAID-MERCURI" target="_blank" rel="noopener">Offer Accepted, What Recruiting Teams Can Learn From Customer Support (Natalie Mercuri)</a><span class="why">Plaid's two-person recruiting ops team treats every hiring question as a support ticket in Linear with Glean layered on top, and validating an AI-drafted reply takes about a minute against roughly 12 minutes writing one from scratch.</span></span></li>
      <li><span class="pick">Newsletter</span><span class="body"><a href="https://promptmates.beehiiv.com/p/what-happens-when-ai-starts-doing-the-work" target="_blank" rel="noopener">PromptMates Newsletter, What Happens When AI Starts Doing the Work?</a><span class="why">Recruiting work is mostly evaluation, not generation, so build a "judgment model" that returns a decision plus a confidence score for triage and QA, and in a Zapier survey just 15% of governed firms give AI full autonomy.</span></span></li>
      <li><span class="pick">Report</span><span class="body"><a href="https://www.bullhorn.com/insights/staffing-industry-indicator/" target="_blank" rel="noopener">Bullhorn Staffing Industry Indicator, week ending 12 September 2026</a><span class="why">US staffing hours ran 11% above 2025 levels even through a short Labor Day week, with Light Industrial up 17% year over year, a number worth having ready before your next staffing conversation.</span></span></li>
      <li><span class="pick">Launch</span><span class="body"><a href="https://www.globenewswire.com/news-release/2026/09/14/3361284/0/en/workable-brings-its-new-line-of-ai-recruiting-agents-to-general-availability-with-new-credit-based-pricing-model-and-expanded-mcp-capabilities.html" target="_blank" rel="noopener">Workable AI Recruiting Agents</a><span class="why">Four named agents, Job Brief, Sourcing, Screening and Engagement, are now generally available on credit-based pricing, plus an MCP server that reaches them from inside Claude or ChatGPT.</span></span></li>
    </ul>'''

assert old in s, "old summary block not found"
s = s.replace(old, new)
open(path, "w", encoding="utf-8").write(s)
print("summary block replaced, AI pick row dropped (no qualifying episode this week)")

path = "digest/builds/2026-09-23.html"
s = open(path, encoding="utf-8").read()

old = '''    <summary class="sec"><span class="lbl">Recruiting Podcasts</span><span class="cnt">{{N}}</span><span class="chev" aria-hidden="true">›</span></summary>
    <div class="sbody">
    <article class="item last">
      <div class="chead"><span class="src">{{Recruiting Show}}</span><span class="cdate">{{DD Mon 2026}}</span></div>
      <a class="ttl" href="{{url}}" target="_blank" rel="noopener">{{clean episode title}}</a>
      <div class="guest">{{Guest Name}} · {{Job Title}} @ {{Company}}</div>
      <ul class="pts"><li>{{point one}}</li><li>{{point two}}</li></ul>
    </article>
  </div>'''

new = '''    <summary class="sec"><span class="lbl">Recruiting Podcasts</span><span class="cnt">4</span><span class="chev" aria-hidden="true">›</span></summary>
    <div class="sbody">
    <article class="item">
      <div class="chead"><span class="src">Offer Accepted <span class="brand">by Ashby</span></span><span class="cdate">22 Sep 2026</span></div>
      <a class="ttl" href="https://www.youtube.com/watch?v=-AX6hwt1gcA" target="_blank" rel="noopener">What Recruiting Teams Can Learn From Customer Support</a>
      <div class="guest">Natalie Mercuri &middot; Recruiting Operations Program Manager @ Plaid</div>
      <ul class="pts"><li>Plaid's two-person recruiting operations team treats every hiring question as a support ticket, routed into Linear with Glean layered on top, across roughly 10,000 interviews a year.</li><li>Natalie Mercuri puts first-reply resolution at about 85%, but she is upfront that it is a self-reported estimate rather than something the team currently measures.</li><li>Validating an AI-drafted reply takes Mercuri about a minute, against roughly 12 minutes to research and write the answer from scratch.</li></ul>
    </article>
    <article class="item">
      <div class="chead"><span class="src">Recruiting Roadshow <span class="brand">by Greenhouse</span></span><span class="cdate">22 Sep 2026</span></div>
      <a class="ttl" href="https://www.youtube.com/watch?v=0f4mswVsXcg" target="_blank" rel="noopener">Candidate fraud is a business problem</a>
      <div class="guest">Adrian Russo &middot; VP of Talent @ Swish Analytics</div>
      <ul class="pts"><li>Watch your baseline applicant volume by role: Russo's full stack engineer openings normally draw about 500 applicants, so an unexplained jump to a thousand resumes, with no campaign change, should be a red flag.</li><li>Russo puts the fraud motive on stealing IP rather than a paycheck, naming China and North Korea as the main source countries and Iran as a much smaller factor.</li><li>He describes one "well known and reputable" security company, name withheld, where a North Korean candidate passed screening, a background check and I-9 verification, then uploaded malware before being caught.</li></ul>
    </article>
    <article class="item">
      <div class="chead"><span class="src">Recruiting Future</span><span class="cdate">18 Sep 2026</span></div>
      <a class="ttl" href="https://www.youtube.com/watch?v=0w1eNSYhjjw" target="_blank" rel="noopener">The Real Risks Of Candidate Fraud</a>
      <ul class="pts"><li>The guest, Lauren Furey, works at Proof, which sponsors this episode and sells identity verification for exactly this problem. She says the fraud rings chase pay for a government and access to source code, customer data and IP.</li><li>The proxy trick: a candidate attends one interview stage, then someone else takes the next, which works because there is "no through line for who are you expecting to meet with" once a new interviewer joins.</li><li>Furey's fix: verify identity before the hiring-manager call or phone screen rather than at application, saving the photo in the ATS as a reference point, or gating access behind a biometric selfie for tougher cases.</li></ul>
    </article>
    <article class="item last">
      <div class="chead"><span class="src">PromptMates Live</span><span class="cdate">16 Sep 2026</span></div>
      <a class="ttl" href="https://www.youtube.com/watch?v=gpPhW4Hvfko" target="_blank" rel="noopener">How to Build Claude Skills for Recruiting</a>
      <ul class="pts"><li>Jake Lamb built a screen summary skill that combines a CV with the Ashby notetaker transcript, cutting his writeup time from four or five hours a week to about 30 minutes.</li><li>His sourcing skill sent "12 agents per area" into a shared Google Sheet and mapped over 200 companies across London and New York in about two hours.</li><li>Before rollout, Shay Mcintosh has Claude "play the role of a QA" and test edge cases first, which can spin up 25 to 50 agents in one run if left uncapped.</li></ul>
    </article>
  </div>'''

assert old in s, "section1 template block not found"
s = s.replace(old, new)
open(path, "w", encoding="utf-8").write(s)
print("section1 done")

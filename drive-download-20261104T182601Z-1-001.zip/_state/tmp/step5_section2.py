path = "digest/builds/2026-09-23.html"
s = open(path, encoding="utf-8").read()

old = '''    <summary class="sec"><span class="lbl">Recruiting Newsletters</span><span class="cnt">{{N}}</span><span class="chev" aria-hidden="true">›</span></summary>
    <div class="sbody">
    <article class="item last">
      <div class="chead"><span class="src">{{Newsletter Name}}</span><span class="cdate">{{DD Mon 2026}}</span></div>
      <a class="ttl" href="{{url}}" target="_blank" rel="noopener">{{issue title}}</a>
      <ul class="pts"><li>{{point one}}</li><li>{{point two}}</li><li>{{point three, optional}}</li></ul>
    </article>
  </div>'''

new = '''    <summary class="sec"><span class="lbl">Recruiting Newsletters</span><span class="cnt">4</span><span class="chev" aria-hidden="true">›</span></summary>
    <div class="sbody">
    <article class="item">
      <div class="chead"><span class="src">PromptMates Newsletter</span><span class="cdate">22 Sep 2026</span></div>
      <a class="ttl" href="https://mail.google.com/mail/u/0/#all/1a0c9350c4088c3b" target="_blank" rel="noopener">What Happens When AI Starts Doing the Work?</a>
      <ul class="pts"><li>Most recruiting work is evaluation, not generation, so a "judgment model" returning a decision plus a confidence score suits outreach QA, candidate rediscovery and application triage better than a text-writing one.</li><li>In a Zapier survey of 518 executives at companies with an AI governance policy, just 15% give AI full unsupervised autonomy, while 38% say ungoverned AI has already cost them time, money or reputation.</li><li>Basis turned its onboarding knowledge into an AI-executable skill and compressed a two-hour first-day process into 30 minutes.</li></ul>
    </article>
    <article class="item">
      <div class="chead"><span class="src">TA Unboxed</span><span class="cdate">22 Sep 2026</span></div>
      <a class="ttl" href="https://mail.google.com/mail/u/0/#all/1a0c7f95c41d201f" target="_blank" rel="noopener">Quality, cost and capacity: the TA metrics that matter</a>
      <ul class="pts"><li>Google's internal research found four interviews enough to predict whether someone should be hired with 86% confidence, a ceiling worth knowing before you add a fifth round out of habit.</li><li>Hires who went through a structured interview process averaged 4.3 out of 5 in quality six months in, against 3.1 out of 5 for hires who went through an informal chat process.</li><li>TA Unboxed cites a Gartner forecast that by 2028, one in four candidate profiles worldwide will be fake, worth planning your verification process around now.</li></ul>
    </article>
    <article class="item">
      <div class="chead"><span class="src">Remade.md</span><span class="cdate">18 Sep 2026</span></div>
      <a class="ttl" href="https://mail.google.com/mail/u/0/#all/1a0b4c3e44a7d3b1" target="_blank" rel="noopener">My AI is making me a better person</a>
      <ul class="pts"><li>The author built a multi-agent "board" from Grokbot and TANI that talked them out of an unpaid speaking gig, saying it made them "look properly at what saying yes would cost me."</li><li>They picture the same setup wired into an ATS, so when a candidate asks for an update the agent drafts a follow-up for a recruiter to review rather than answering on its own.</li></ul>
    </article>
    <article class="item last">
      <div class="chead"><span class="src">RecOps Roundup</span><span class="cdate">17 Sep 2026</span></div>
      <a class="ttl" href="https://mail.google.com/mail/u/0/#all/1a0b1b30981c646e" target="_blank" rel="noopener">Week of September 14th, 2026</a>
      <ul class="pts"><li>HiPeople's AI screening tool now runs on GPT-6 Astra and GPT-5.6 SOL, the latest example of a vendor swapping in newer models without changing the product name.</li><li>Metaview's fillmore agent moved out of beta into general availability, alongside a piece on "detecting excessive initiative" in it.</li><li>The 2026 ROCA awards are returning, with categories opening in mid-October and winners announced in early December.</li></ul>
    </article>
  </div>'''

assert old in s, "section2 template block not found"
s = s.replace(old, new)
open(path, "w", encoding="utf-8").write(s)
print("section2 done")

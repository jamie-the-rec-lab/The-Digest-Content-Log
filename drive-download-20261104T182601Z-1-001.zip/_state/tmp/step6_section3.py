path = "digest/builds/2026-09-23.html"
s = open(path, encoding="utf-8").read()

old = '''    <summary class="sec"><span class="lbl">Recruiting reports, product updates, and more</span><span class="cnt">{{N}}</span><span class="chev" aria-hidden="true">›</span></summary>
    <div class="sbody">
    <article class="item">
      <div class="chead"><span class="src">{{Source}} · {{report|event|launch|essay}}</span><span class="cdate">{{Mon 2026}}</span></div>
      <a class="ttl" href="{{url}}" target="_blank" rel="noopener">{{item title}}</a>
      <ul class="pts"><li>{{point one}}</li><li>{{point two}}</li></ul>
    </article>
    <article class="item last">
      <div class="chead"><span class="src">{{Vendor}} · launches</span><span class="cdate">{{Mon 2026}}</span></div>
      <div class="vgroup-title">{{GROUPED-VENDOR launch block: use ONLY when one vendor has 2+ material releases this week, collapse them here as ONE block. One-line vendor header, e.g. "Greenhouse ships two". For a SINGLE launch use the normal single-item article above with src "{{Vendor}} · launch" and a linked title, and DELETE this grouped article.}}</div>
      <ul class="pts"><li><a href="{{release 1 url}}" target="_blank" rel="noopener"><span class="rt">{{release 1 name}}</span> {{what it does + so-what, one line}}</a></li><li><a href="{{release 2 url}}" target="_blank" rel="noopener"><span class="rt">{{release 2 name}}</span> {{what it does + so-what, one line}}</a></li></ul>
    </article>
  </div>'''

new = '''    <summary class="sec"><span class="lbl">Recruiting reports, product updates, and more</span><span class="cnt">3</span><span class="chev" aria-hidden="true">›</span></summary>
    <div class="sbody">
    <article class="item">
      <div class="chead"><span class="src">Bullhorn &middot; report</span><span class="cdate">23 Sep 2026</span></div>
      <a class="ttl" href="https://www.bullhorn.com/insights/staffing-industry-indicator/" target="_blank" rel="noopener">Staffing Industry Indicator, week ending 12 September 2026</a>
      <ul class="pts"><li>US staffing hours ran 11% above 2025 levels in the week ending 12 September, even with a short Labor Day week in the mix.</li><li>US Light Industrial was the strongest segment, 17% above last year, while US Office and Clerical was the only segment down, 5% below.</li><li>US average weekly hours per worker fell to 32.4 from 35.1 the prior week, which Bullhorn reads as a holiday effect rather than a shift in demand.</li></ul>
    </article>
    <article class="item">
      <div class="chead"><span class="src">Pin &middot; launch</span><span class="cdate">15 Sep 2026</span></div>
      <a class="ttl" href="https://www.pin.com/blog/talent-preview" target="_blank" rel="noopener">Talent Preview</a>
      <ul class="pts"><li>Pin's Talent Preview shows your candidate pool size, salary ranges, company sizes, skills and geography, updating live as you type your search criteria before you ever hit search.</li><li>Pin frames it simply: "See your talent pool as you type, before you hit search."</li></ul>
    </article>
    <article class="item last">
      <div class="chead"><span class="src">Workable &middot; launch</span><span class="cdate">14 Sep 2026</span></div>
      <a class="ttl" href="https://www.globenewswire.com/news-release/2026/09/14/3361284/0/en/workable-brings-its-new-line-of-ai-recruiting-agents-to-general-availability-with-new-credit-based-pricing-model-and-expanded-mcp-capabilities.html" target="_blank" rel="noopener">AI Recruiting Agents</a>
      <ul class="pts"><li>Workable's four AI agents, Job Brief, Sourcing, Screening and Engagement, are now generally available, covering most of a requisition's early workflow.</li><li>Pricing runs on credits, with 3,000 free credits included per plan, and an MCP server lets you reach the agents from inside Claude or ChatGPT.</li><li>Workable's CEO Nikos Moraitakis frames it as a shift from "assistive gimmicks" to "real ROI from process automation."</li></ul>
    </article>
  </div>'''

assert old in s, "section3 template block not found"
s = s.replace(old, new)
open(path, "w", encoding="utf-8").write(s)
print("section3 done")

path = "digest/builds/2026-09-23.html"
s = open(path, encoding="utf-8").read()

old = '''    <summary class="sec"><span class="lbl">AI &amp; Tech Picks</span><span class="cnt">{{N}}</span><span class="chev" aria-hidden="true">›</span></summary>
    <div class="sbody">
    <article class="item last">
      <div class="chead"><span class="src">{{Tech Show, e.g. Lenny's Podcast}}</span><span class="cdate">{{DD Mon 2026}}</span></div>
      <a class="ttl" href="{{url}}" target="_blank" rel="noopener">{{clean episode title}}</a>
      <div class="guest">{{Guest Name}} · {{Job Title}} @ {{Company}}</div>
      <ul class="pts"><li>{{point one}}</li><li>{{point two}}</li></ul>
    </article>
  </div>'''

new = '''    <summary class="sec"><span class="lbl">AI &amp; Tech Picks</span><span class="cnt">1</span><span class="chev" aria-hidden="true">›</span></summary>
    <div class="sbody">
    <article class="item last">
      <div class="chead"><span class="src">MultiState &middot; news</span><span class="cdate">21 Sep 2026</span></div>
      <a class="ttl" href="https://www.multistate.us/insider/2026/9/21/state-ai-employment-laws-address-monitoring-hiring-and-bias-concerns" target="_blank" rel="noopener">State AI employment laws: Colorado and Connecticut enact hiring rules, California's neural-data ban awaits signature</a>
      <ul class="pts"><li>States considered 155 bills addressing AI in the workplace this legislative session, and only two, Colorado's SB 189 and Connecticut's SB 5, actually enacted notify-and-explain rules for automated hiring tools.</li><li>California's AB 1883, which would ban AI monitoring of workers' neural data and emotional state, has passed the legislature and is headed to Governor Newsom, who has vetoed a similar bill before.</li><li>Bias and impact-assessment mandates were proposed in multiple states this session, and all of them died in committee.</li></ul>
    </article>
  </div>'''

assert old in s, "section4 template block not found"
s = s.replace(old, new)
open(path, "w", encoding="utf-8").write(s)
print("section4 done")

# -*- coding: utf-8 -*-
path = "digest/builds/2026-09-23.html"
s = open(path, encoding="utf-8").read()

fixes = [
  # Offer Accepted bullet 1: trim trailing clause
  ('<li>Plaid\'s two-person recruiting operations team treats every hiring question as a support ticket, routed into Linear with Glean layered on top, across roughly 10,000 interviews a year.</li>',
   '<li>Plaid\'s two-person recruiting operations team treats every hiring question as a support ticket, routed into Linear with Glean layered on top.</li>'),

  # Roadshow bullet 1: trim
  ('<li>Watch your baseline applicant volume by role: Russo\'s full stack engineer openings normally draw about 500 applicants, so an unexplained jump to a thousand resumes, with no campaign change, should be a red flag.</li>',
   '<li>Watch your baseline applicant volume by role: Russo\'s full stack engineer openings normally draw about 500 applicants, so an unexplained jump to a thousand with no campaign change should raise alarms.</li>'),

  # Roadshow bullet 3: unnamed
  ('<li>He describes one "well known and reputable" security company, name withheld, where a North Korean candidate passed screening, a background check and I-9 verification, then uploaded malware before being caught.</li>',
   '<li>Russo describes an unnamed "well known and reputable" security company where a North Korean candidate passed screening, a background check and I-9 verification, then uploaded malware before being caught.</li>'),

  # RF ep825 bullet 1: single-idea vendor disclosure
  ('<li>The guest, Lauren Furey, works at Proof, which sponsors this episode and sells identity verification for exactly this problem. She says the fraud rings chase pay for a government and access to source code, customer data and IP.</li>',
   '<li>This week\'s guest, Lauren Furey, is a product manager at Proof, which sponsors the episode and sells identity verification into exactly the problem she is describing.</li>'),

  # PromptMates Newsletter bullet 1
  ('<li>Most recruiting work is evaluation, not generation, so a "judgment model" returning a decision plus a confidence score suits outreach QA, candidate rediscovery and application triage better than a text-writing one.</li>',
   '<li>Recruiting work is often evaluation rather than generation, so build a "judgment model" that returns a decision plus a confidence score, useful for outreach QA and application triage.</li>'),

  # Bullhorn bullet 2
  ('<li>US Light Industrial was the strongest segment, 17% above last year, while US Office and Clerical was the only segment down, 5% below.</li>',
   '<li>US Light Industrial led all segments at 17% above last year, while US Office and Clerical was the only one down, 5% below.</li>'),

  # Workable bullet 2 split into pricing + MCP, drop CEO quote bullet
  ('<li>Pricing runs on credits, with 3,000 free credits included per plan, and an MCP server lets you reach the agents from inside Claude or ChatGPT.</li><li>Workable\'s CEO Nikos Moraitakis frames it as a shift from "assistive gimmicks" to "real ROI from process automation."</li>',
   '<li>Pricing runs on credits, with 3,000 free credits included in every plan.</li><li>An MCP server lets you reach the four agents from inside Claude or ChatGPT, rather than only through Workable\'s own interface.</li>'),

  # MultiState bullet 1
  ('<li>States considered 155 bills addressing AI in the workplace this legislative session, and only two, Colorado\'s SB 189 and Connecticut\'s SB 5, actually enacted notify-and-explain rules for automated hiring tools.</li>',
   '<li>States considered 155 bills addressing AI in the workplace this legislative session, and only Colorado\'s SB 189 and Connecticut\'s SB 5 actually enacted notify-and-explain rules for automated hiring tools.</li>'),

  # Remade.md bullet 2: name the subject instead of "They"
  ('<li>They picture the same setup wired into an ATS, so when a candidate asks for an update the agent drafts a follow-up for a recruiter to review rather than answering on its own.</li>',
   '<li>Leandro pictures the same setup wired into an ATS, so when a candidate asks for an update the agent drafts a follow-up for a recruiter to review rather than answering on its own.</li>'),
  ('<li>The author built a multi-agent "board" from Grokbot and TANI that talked them out of an unpaid speaking gig, saying it made them "look properly at what saying yes would cost me."</li>',
   '<li>Leandro built a multi-agent "board" from Grokbot and TANI that talked him out of an unpaid speaking gig, saying it made him "look properly at what saying yes would cost me."</li>'),
]

missing = []
for old, new in fixes:
    if old not in s:
        missing.append(old[:80])
    else:
        s = s.replace(old, new)

if missing:
    print("MISSING (not found, check manually):")
    for m in missing:
        print(" -", m)
else:
    print("all fixes applied cleanly")

open(path, "w", encoding="utf-8").write(s)

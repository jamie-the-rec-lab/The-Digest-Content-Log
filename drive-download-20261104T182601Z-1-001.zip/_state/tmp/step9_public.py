path = "digest/builds/2026-09-23.html"
s = open(path, encoding="utf-8").read()

swaps = {
  "https://mail.google.com/mail/u/0/#all/1a0c9350c4088c3b": "https://promptmates.beehiiv.com/p/what-happens-when-ai-starts-doing-the-work",
  "https://mail.google.com/mail/u/0/#all/1a0c7f95c41d201f": "https://taunboxed.substack.com/p/quality-cost-and-capacity-the-ta",
  "https://mail.google.com/mail/u/0/#all/1a0b4c3e44a7d3b1": "https://remadebyleandro.substack.com/p/my-ai-is-making-me-a-better-person",
  "https://mail.google.com/mail/u/0/#all/1a0b1b30981c646e": "https://recops.substack.com/p/week-of-september-14th-2026",
}
missing = []
for old, new in swaps.items():
    if old not in s:
        missing.append(old)
    else:
        s = s.replace(old, new)

if missing:
    print("MISSING:", missing)
else:
    print("all newsletter links swapped to public URLs")

out = "/tmp/public-2026-09-23.html"
open(out, "w", encoding="utf-8").write(s)
print("wrote", out)

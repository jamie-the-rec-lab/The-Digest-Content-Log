#!/usr/bin/env python3
"""
Lightweight index builder for the SEPARATE `tech/` collection (e.g. Lenny's
Podcast). This collection is deliberately NOT part of the talent "recruiting
brain": it is a large archive kept out of default recall and only surfaced on
demand or fed into the weekly digest.

Unlike the core collection, tech transcripts are NOT given rich per-episode
LLM summary blocks (there are hundreds of them and they are rarely recalled).
Instead this script auto-generates one lightweight episode_summaries.tsv line
per transcript, purely mechanically (no LLM):
  - summary  = the first paragraph of the episode description (truncated)
  - company  = the guest/company part of the "Title | Guest, Company" line
  - tags     = 1-5 tags keyword-matched against tech/TAXONOMY.md

Run:  python3 tech/build_tech_index.py   (regenerates the TSV)
then: python3 build_index.py tech        (rebuilds tech/INDEX.md)

Safe to re-run: it rewrites the whole TSV from whatever transcripts exist, so
new episodes fetched by the weekly job are picked up automatically.
"""
import os, re, glob
from collections import Counter

BASE = os.path.dirname(os.path.abspath(__file__))            # the tech/ folder
TDIR = os.path.join(BASE, "transcripts")

# keyword -> tag. Every tag here MUST exist in tech/TAXONOMY.md.
RULES = [
    (r"\bai\b|artificial intelligence|\bllm|\bgpt|chatgpt|openai|anthropic|claude|gemini|\bmodel\b", "ai"),
    (r"agent", "ai agents"),
    (r"coding|\bcode\b|codex|copilot|cursor|engineer", "ai coding"),
    (r"product manager|product management|\bpm\b|\bcpo\b|head of product|chief product", "product management"),
    (r"product strategy|roadmap|product-market|product market", "product strategy"),
    (r"design|designer|\bux\b|\bui\b", "product design"),
    (r"user research|customer research|research", "user research"),
    (r"pricing|monetization|monetisation", "pricing"),
    (r"growth|acquisition|retention|virality|funnel", "growth"),
    (r"data|analytics|metrics|experiment|a/b", "data and analytics"),
    (r"startup|founder|found a|co-found|solo found", "startups"),
    (r"founder|\bceo\b|built .* company|building .* company", "founder stories"),
    (r"fundrais|raise|series [a-e]|venture|\bvc\b|seed round", "fundraising"),
    (r"go-to-market|gtm|sales|marketing|demand gen", "go-to-market"),
    (r"scal|hypergrowth|zero to one|0 to 1", "scaling"),
    (r"leader|leadership|exec|c-suite|\bcto\b|\bcfo\b|\bcoo\b", "leadership"),
    (r"manage|management|managing", "management"),
    (r"hir|recruit|talent|interview", "hiring"),
    (r"team|culture|\borg\b|organization|organisation", "team building"),
    (r"career|\bjob\b|promotion|your story", "careers"),
    (r"productivity|habits|time management|focus", "productivity"),
    (r"future of work|remote|ai era|ai world|\bjobs\b", "future of work"),
]

def clean(s):
    return re.sub(r"\s+", " ", s).strip()

def parse(path, show):
    txt = open(path, encoding="utf-8").read()
    m = re.search(r"^#\s+(.+)$", txt, re.M)
    title = clean(m.group(1)) if m else os.path.basename(path)
    md = re.search(r"\*\*Date:\*\*\s*([0-9]{4}-[0-9]{2}-[0-9]{2})", txt)
    date = md.group(1) if md else ""
    company = clean(title.split("|", 1)[1]) if "|" in title else show
    summary = title
    dm = re.search(r"##\s*Episode description\s*(.+?)(?:\n\n|\*In our)", txt, re.S)
    if dm:
        para = re.sub(r"^\*+|\*+$", "", clean(dm.group(1))).strip()
        if len(para) > 40:
            summary = para[:220].rstrip()
            if not summary.endswith('.'):
                summary = summary.rsplit(' ', 1)[0] + " ..."
    hay = (title + " " + summary).lower()
    tags = []
    for pat, tag in RULES:
        if re.search(pat, hay) and tag not in tags:
            tags.append(tag)
    return date, title, company, summary, (tags[:5] or ["general"])

def main():
    rows = []
    for show in sorted(os.listdir(TDIR)):
        d = os.path.join(TDIR, show)
        if not os.path.isdir(d) or show.startswith("_"):
            continue
        for path in glob.glob(os.path.join(d, "*.md")):
            date, title, company, summary, tags = parse(path, show)
            summary = summary.replace("|||", " ").replace("|", "/")
            company = company.replace("|||", " ").replace("|", "/")
            rows.append((date, f"{show}/{os.path.basename(path)}", summary, company, ", ".join(tags)))
    rows.sort(key=lambda r: r[0], reverse=True)
    with open(os.path.join(BASE, "episode_summaries.tsv"), "w", encoding="utf-8") as f:
        for _d, rel, summary, company, tags in rows:
            f.write(f"{rel}|||{summary}|||{company}|||{tags}\n")
    print(f"wrote {len(rows)} TSV lines")
    c = Counter(t for r in rows for t in r[4].split(", "))
    print("top tags:", c.most_common(8))

if __name__ == "__main__":
    main()
